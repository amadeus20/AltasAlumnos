﻿using Microsoft.AspNetCore.Mvc;

namespace Altas.Controllers
{
    public class OperacionesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult OperacionesB()
        {
            return View();
        }
        public IActionResult Opc(double Numero1, double Numero2, int Operaciones)
        {
            double Resultado=0;
            ViewData["Numero1"] = Numero1;
            ViewData["Numero2"] = Numero2;
            switch (Operaciones)
            {
                case 0:
                    Resultado=Numero1+ Numero2;
                    break;
                case 1:
                    Resultado=Numero1- Numero2;
                    break;
                case 2:
                    Resultado = Numero1 * Numero2;
                    break;
                case 3:
                    Resultado = Numero1 / Numero2;
                    break;
                    
            }
            ViewData["Resultado"] = Resultado;
            return View();
        }
    }
}
