﻿using Microsoft.AspNetCore.Mvc;

namespace Altas.Controllers
{
    public class AlumnoController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Alta()
        {
            return View();
        }
        public IActionResult Confirmar(string Alumno, string Grupo, double Boleta, int Carrera)
        {
            ViewData["Alumno"] = Alumno;
            ViewData["Grupo"] = Grupo;
            ViewData["Boleta"] = Boleta;
            switch (Carrera)
            {
                case 0:
                    ViewData["Carrera"] = "Informática";
                    break;
                case 1:
                    ViewData["Carrera"] = "Ciberseguridad";
                    break;
                case 2:
                    ViewData["Carrera"] = "Turismo";
                    break;
                case 3:
                    ViewData["Carrera"] = "Adaministración";
                    break;
                case 4:
                    ViewData["Carrera"] = "Contabilidad";
                    break;
                case 5:
                    ViewData["Carrera"] = "Gastronomía";
                    break;
            }
            return View();
        }
    }
}
