﻿using Microsoft.AspNetCore.Mvc;
using System.Web;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Altas.Controllers
{
    public class EmpleadoController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Alta()
        {
            return View();
        }
        public IActionResult Confirmar(double NoEmpleado, string Nombre, string ApPaterno, string ApMaterno, int Area, string Fecha)
        {
            ViewData["NoEmpleado"] = NoEmpleado;
            ViewData["Nombre"] = Nombre;
            ViewData["ApPaterno"] = ApPaterno;
            ViewData["ApMaterno"] = ApMaterno;
            ViewData["Fecha"] = Fecha;
            switch (Area)
            {
                case 0:
                    ViewData["Area"] = "Financiera";
                    break;
                case 1:
                    ViewData["Area"] = "Programación";
                    break;
                case 2:
                    ViewData["Area"] = "Limpieza";
                    break;
                case 3:
                    ViewData["Area"] = "Marketing";
                    break;
                case 4:
                    ViewData["Area"] = "Contabilidad";
                    break;
            }
            return View();
        }


    }
}
